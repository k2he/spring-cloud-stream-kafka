package com.springcloudstreamkafka.consumertsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerTsysApplicationTests {

	@Test
	void contextLoads() {
	}

}
